Many thanks to the following parties.  

All materials licensed under CC0 unless otherwise specified.

Software: 
  
Audacity (http://audacityteam.org/) 
Audio Tool (https://www.audiotool.com/)
Construct 2 (Paid version) by Scirra (https://www.scirra.com/)
Kenney Studio (http://kenney.nl/projects/kenney-studio)
Inkscape (https://inkscape.org/en/)
ShoeBox (http://renderhjs.net/shoebox/)
        
Graphics:

Kenney (www.kenney.nl)
Donate: http://donate.kenney.nl/
Request: http://request.kenney.nl/

Fonts: 

Almendra Bold by Ana Sanfelippo (https://www.fontsquirrel.com/fonts/almendra)

Audio:

Licenses were purchased for the following sounds through soundsnap.com (re-distribution of sounds "as is" not permitted)

"Door Slam Bounce Open" by Justine Angus
"Video Game Joystick Button Push Switch" by Blastwave FX
"Gameboy Game Blip" by L&F Music
"Descending Gamey Blip" by L&F Music

Game theme created with audiotool and prominently featuring "CELLO ENS" by GRANPAW with CC BY-SA licensing. 
(https://www.audiotool.com/track/platformer_game_theme)